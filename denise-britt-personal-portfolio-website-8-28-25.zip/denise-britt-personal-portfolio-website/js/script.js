// === Main DOM Ready Logic ===
document.addEventListener('DOMContentLoaded', () => {
  const sections = [
    { id: 'about', file: 'html/about.html' },
    { id: 'projects', file: 'html/projects.html' },
    { id: 'resume', file: 'html/resume.html' },
    { id: 'contact', file: 'html/contact.html' }
  ];

  sections.forEach(({ id, file }) => {
    const container = document.getElementById(id);
    if (!container) return;

    fetch(file)
      .then(res => res.ok ? res.text() : Promise.reject(`Failed to load ${file}`))
      .then(html => {
        container.innerHTML = `<div class="section-inner">${html}</div>`;
      })
      .catch(err => {
        console.error(err);
        container.innerHTML = `<p class="error">Error loading ${file}</p>`;
      });
  });

  
// === Hamburger Menu Toggle ===
  const hamburger = document.getElementById('hamburgerBtn');
  const navMenu = document.querySelector('.site-nav ul');
  hamburger?.addEventListener('click', () => navMenu.classList.toggle('open'));


// === LinkedIn Button Handler ===
  const linkedinButtons = document.querySelectorAll('.linkedin-button');
  const linkedInURL = "https://www.linkedin.com/in/denisebritt";

  linkedinButtons.forEach(button => {
    button.addEventListener('click', () => {
      window.open(linkedInURL, '_blank');
    });
  });
});

